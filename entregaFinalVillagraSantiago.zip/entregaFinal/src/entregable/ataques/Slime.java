package entregable.ataques;

import game.attacks.Attack;

public interface Slime extends Attack{

}
