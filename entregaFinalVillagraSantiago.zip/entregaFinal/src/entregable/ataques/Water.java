package entregable.ataques;

import game.attacks.Attack;

public interface Water extends Attack{

}
