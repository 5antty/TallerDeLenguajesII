package entregable.ataques;

import game.attacks.Attack;

public interface Electricity extends Attack{

}
