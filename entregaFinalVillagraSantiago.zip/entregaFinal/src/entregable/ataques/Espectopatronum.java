package entregable.ataques;

import game.components.Monster;

public class Espectopatronum implements Wizard{
	@Override
	public int damage(Monster monster) {
		return 250;
	}
}
