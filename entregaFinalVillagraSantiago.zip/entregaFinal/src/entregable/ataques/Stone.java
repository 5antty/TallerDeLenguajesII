package entregable.ataques;

import game.attacks.Attack;

public interface Stone extends Attack{

}
