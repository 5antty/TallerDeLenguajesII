package game.types;

public enum Type {
    COLD,
    FIRE,
    DEMON,
    SWORD,
    BEAST,
    WATER,
    STONE,
    ELECTRICITY,
    SLIME,
    WIZARD
    
}
