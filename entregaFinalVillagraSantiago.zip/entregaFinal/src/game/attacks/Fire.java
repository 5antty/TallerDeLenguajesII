package game.attacks;

public interface Fire extends Attack {
}
