package game.attacks;

public interface Demon extends Attack {
}
