package game.attacks;

public interface Cold extends Attack {
}
