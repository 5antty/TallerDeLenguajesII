package game.attacks;

public interface Beast extends Attack {
}
