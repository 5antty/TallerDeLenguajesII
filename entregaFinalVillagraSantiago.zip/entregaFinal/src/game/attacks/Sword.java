package game.attacks;

public interface Sword extends Attack {
}
